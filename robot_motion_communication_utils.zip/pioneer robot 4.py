import math
import time
from robot_motion_communication_utils import *
import socket
import threading
from central_dictionary_handling_utils_sept24 import*

running = True
robot_position = [-25,-10]
robot_name = 'robot4'
#copy the grid point from the result of Multi Robot Area Allocation & TSP opt- Main file - Sept 24 file
sequence = [(-25, -10), (-25.0, -10.0), (-25.0, -11.0), (-25.0, -12.0), (-25.0, -13.0), (-25.0, -14.0), (-25.0, -15.0), (-24.0, -15.0), (-24.0, -14.0), (-24.0, -13.0), (-24.0, -12.0), (-24.0, -11.0), (-24.0, -10.0), (-24.0, -9.0), (-25.0, -9.0), (-25.0, -8.0), (-25.0, -7.0), (-25.0, -6.0), (-24.0, -6.0), (-24.0, -7.0), (-24.0, -8.0), (-23.0, -8.0), (-23.0, -9.0), (-23.0, -10.0), (-23.0, -11.0), (-23.0, -12.0), (-23.0, -13.0), (-23.0, -14.0), (-23.0, -15.0), (-22.0, -15.0), (-22.0, -14.0), (-22.0, -13.0), (-22.0, -12.0), (-22.0, -11.0), (-22.0, -10.0), (-22.0, -9.0), (-22.0, -8.0), (-22.0, -7.0), (-23.0, -7.0), (-23.0, -6.0), (-22.0, -6.0), (-21.0, -6.0), (-21.0, -7.0), (-21.0, -8.0), (-21.0, -9.0), (-21.0, -10.0), (-21.0, -11.0), (-21.0, -12.0), (-21.0, -13.0), (-21.0, -14.0), (-21.0, -15.0), (-20.0, -15.0), (-20.0, -14.0), (-20.0, -13.0), (-20.0, -12.0), (-20.0, -11.0), (-20.0, -10.0), (-20.0, -9.0), (-20.0, -8.0), (-20.0, -7.0), (-20.0, -6.0), (-19.0, -6.0), (-19.0, -7.0), (-19.0, -8.0), (-19.0, -9.0), (-19.0, -10.0), (-19.0, -11.0), (-19.0, -12.0), (-19.0, -13.0), (-19.0, -14.0), (-19.0, -15.0), (-18.0, -15.0), (-18.0, -14.0), (-18.0, -13.0), (-18.0, -12.0), (-18.0, -11.0), (-18.0, -10.0), (-18.0, -9.0), (-18.0, -8.0), (-18.0, -7.0), (-18.0, -6.0), (-17.0, -6.0), (-17.0, -7.0), (-17.0, -8.0), (-17.0, -9.0), (-17.0, -10.0), (-17.0, -11.0), (-17.0, -12.0), (-17.0, -13.0), (-17.0, -14.0), (-17.0, -15.0), (-16.0, -15.0), (-16.0, -14.0), (-16.0, -13.0), (-16.0, -12.0), (-16.0, -11.0), (-16.0, -10.0), (-16.0, -9.0), (-16.0, -8.0), (-16.0, -7.0), (-16.0, -6.0), (-15.0, -6.0), (-15.0, -7.0), (-15.0, -8.0), (-15.0, -9.0), (-15.0, -10.0), (-15.0, -11.0), (-15.0, -12.0), (-15.0, -13.0), (-15.0, -14.0), (-15.0, -15.0), (-14.0, -15.0), (-14.0, -14.0), (-14.0, -13.0), (-14.0, -12.0), (-14.0, -11.0), (-14.0, -10.0), (-14.0, -9.0), (-14.0, -8.0), (-14.0, -7.0), (-14.0, -6.0), (-13.0, -6.0), (-13.0, -7.0), (-13.0, -8.0), (-13.0, -9.0), (-13.0, -10.0), (-13.0, -11.0), (-13.0, -12.0), (-13.0, -13.0), (-13.0, -14.0), (-13.0, -15.0), (-12.0, -15.0), (-12.0, -14.0), (-12.0, -13.0), (-12.0, -12.0), (-12.0, -11.0), (-12.0, -10.0), (-12.0, -9.0), (-12.0, -8.0), (-12.0, -7.0), (-12.0, -6.0), (-11.0, -6.0), (-11.0, -7.0), (-11.0, -8.0), (-11.0, -9.0), (-11.0, -10.0), (-11.0, -11.0), (-11.0, -12.0), (-11.0, -13.0), (-11.0, -14.0), (-11.0, -15.0), (-10.0, -15.0), (-10.0, -14.0), (-10.0, -13.0), (-10.0, -12.0), (-10.0, -11.0), (-10.0, -10.0), (-10.0, -9.0), (-10.0, -8.0), (-10.0, -7.0), (-10.0, -6.0), (-9.0, -6.0), (-9.0, -7.0), (-9.0, -8.0), (-9.0, -9.0), (-9.0, -10.0), (-9.0, -11.0), (-9.0, -12.0), (-9.0, -13.0), (-9.0, -14.0), (-9.0, -15.0), (-8.0, -15.0), (-8.0, -14.0), (-8.0, -13.0), (-8.0, -12.0), (-8.0, -11.0), (-8.0, -10.0), (-8.0, -9.0), (-8.0, -8.0), (-8.0, -7.0), (-8.0, -6.0), (-7.0, -6.0), (-7.0, -7.0), (-7.0, -8.0), (-7.0, -9.0), (-7.0, -10.0), (-7.0, -11.0), (-7.0, -12.0), (-7.0, -13.0), (-7.0, -14.0), (-7.0, -15.0), (-6.0, -15.0), (-6.0, -14.0), (-6.0, -13.0), (-6.0, -12.0), (-6.0, -11.0), (-6.0, -10.0), (-6.0, -9.0), (-6.0, -8.0), (-6.0, -7.0), (-6.0, -6.0), (-5.0, -6.0), (-5.0, -7.0), (-5.0, -8.0), (-5.0, -9.0), (-5.0, -10.0), (-5.0, -11.0), (-5.0, -12.0), (-5.0, -13.0), (-5.0, -14.0), (-5.0, -15.0), (-4.0, -15.0), (-4.0, -14.0), (-4.0, -13.0), (-4.0, -12.0), (-4.0, -11.0), (-4.0, -10.0), (-4.0, -9.0), (-4.0, -8.0), (-4.0, -7.0), (-4.0, -6.0), (-3.0, -6.0), (-3.0, -7.0), (-3.0, -8.0), (-3.0, -9.0), (-3.0, -10.0), (-3.0, -11.0), (-3.0, -12.0), (-3.0, -13.0), (-3.0, -14.0), (-3.0, -15.0), (-2.0, -15.0), (-2.0, -14.0), (-2.0, -13.0), (-2.0, -12.0), (-2.0, -11.0), (-2.0, -10.0), (-2.0, -9.0), (-2.0, -8.0), (-2.0, -7.0), (-2.0, -6.0), (-1.0, -6.0), (-1.0, -7.0), (-1.0, -8.0), (-1.0, -9.0), (-1.0, -10.0), (-1.0, -11.0), (-1.0, -12.0), (-1.0, -13.0), (-1.0, -14.0), (-1.0, -15.0), (0.0, -15.0), (0.0, -14.0), (0.0, -13.0), (0.0, -12.0), (0.0, -11.0), (0.0, -10.0), (0.0, -9.0), (0.0, -8.0), (0.0, -7.0), (0.0, -6.0), (1.0, -6.0), (1.0, -7.0), (1.0, -8.0), (1.0, -9.0), (1.0, -10.0), (1.0, -11.0), (1.0, -12.0), (1.0, -13.0), (1.0, -14.0), (1.0, -15.0), (2.0, -15.0), (2.0, -14.0), (2.0, -13.0), (2.0, -12.0), (2.0, -11.0), (2.0, -10.0), (2.0, -9.0), (2.0, -8.0), (2.0, -7.0), (2.0, -6.0), (3.0, -6.0), (3.0, -7.0), (3.0, -8.0), (3.0, -9.0), (3.0, -10.0), (3.0, -11.0), (3.0, -12.0), (3.0, -13.0), (3.0, -14.0), (3.0, -15.0), (4.0, -15.0), (4.0, -14.0), (4.0, -13.0), (4.0, -12.0), (4.0, -11.0), (4.0, -10.0), (4.0, -9.0), (4.0, -8.0), (4.0, -7.0), (4.0, -6.0), (5.0, -6.0), (5.0, -7.0), (5.0, -8.0), (5.0, -9.0), (5.0, -10.0), (5.0, -11.0), (5.0, -12.0), (5.0, -13.0), (5.0, -14.0), (5.0, -15.0), (6.0, -15.0), (6.0, -14.0), (6.0, -13.0), (6.0, -12.0), (6.0, -11.0), (6.0, -10.0), (6.0, -9.0), (6.0, -8.0), (6.0, -7.0), (6.0, -6.0), (7.0, -6.0), (7.0, -7.0), (7.0, -8.0), (7.0, -9.0), (7.0, -10.0), (7.0, -11.0), (7.0, -12.0), (7.0, -13.0), (7.0, -14.0), (7.0, -15.0), (8.0, -15.0), (8.0, -14.0), (8.0, -13.0), (8.0, -12.0), (8.0, -11.0), (8.0, -10.0), (8.0, -9.0), (8.0, -8.0), (8.0, -7.0), (8.0, -6.0), (9.0, -6.0), (9.0, -7.0), (9.0, -8.0), (9.0, -9.0), (9.0, -10.0), (9.0, -11.0), (9.0, -12.0), (9.0, -13.0), (9.0, -14.0), (9.0, -15.0), (10.0, -15.0), (10.0, -14.0), (10.0, -13.0), (10.0, -12.0), (10.0, -11.0), (10.0, -10.0), (10.0, -9.0), (10.0, -8.0), (10.0, -7.0), (10.0, -6.0), (11.0, -6.0), (11.0, -7.0), (11.0, -8.0), (11.0, -9.0), (11.0, -10.0), (11.0, -11.0), (11.0, -12.0), (11.0, -13.0), (11.0, -14.0), (11.0, -15.0), (12.0, -15.0), (12.0, -14.0), (12.0, -13.0), (12.0, -12.0), (12.0, -11.0), (12.0, -10.0), (12.0, -9.0), (12.0, -8.0), (12.0, -7.0), (12.0, -6.0), (13.0, -6.0), (13.0, -7.0), (13.0, -8.0), (13.0, -9.0), (13.0, -10.0), (13.0, -11.0), (13.0, -12.0), (13.0, -13.0), (13.0, -14.0), (13.0, -15.0), (14.0, -15.0), (14.0, -14.0), (14.0, -13.0), (14.0, -12.0), (14.0, -11.0), (14.0, -10.0), (14.0, -9.0), (14.0, -8.0), (14.0, -7.0), (14.0, -6.0), (15.0, -6.0), (15.0, -7.0), (15.0, -8.0), (15.0, -9.0), (15.0, -10.0), (15.0, -11.0), (15.0, -12.0), (15.0, -13.0), (15.0, -14.0), (15.0, -15.0), (16.0, -15.0), (16.0, -14.0), (16.0, -13.0), (16.0, -12.0), (16.0, -11.0), (16.0, -10.0), (16.0, -9.0), (16.0, -8.0), (16.0, -7.0), (16.0, -6.0), (17.0, -6.0), (17.0, -7.0), (17.0, -8.0), (17.0, -9.0), (17.0, -10.0), (17.0, -11.0), (17.0, -12.0), (17.0, -13.0), (17.0, -14.0), (17.0, -15.0), (18.0, -15.0), (18.0, -14.0), (18.0, -13.0), (18.0, -12.0), (18.0, -11.0), (18.0, -10.0), (18.0, -9.0), (18.0, -8.0), (18.0, -7.0), (18.0, -6.0), (19.0, -6.0), (19.0, -7.0), (19.0, -8.0), (19.0, -9.0), (19.0, -10.0), (19.0, -11.0), (19.0, -12.0), (19.0, -13.0), (19.0, -14.0), (19.0, -15.0), (20.0, -15.0), (20.0, -14.0), (20.0, -13.0), (20.0, -12.0), (20.0, -11.0), (20.0, -10.0), (20.0, -9.0), (20.0, -8.0), (20.0, -7.0), (20.0, -6.0), (21.0, -6.0), (21.0, -7.0), (21.0, -8.0), (21.0, -9.0), (21.0, -10.0), (21.0, -11.0), (21.0, -12.0), (21.0, -13.0), (21.0, -14.0), (21.0, -15.0), (22.0, -15.0), (22.0, -14.0), (22.0, -13.0), (22.0, -12.0), (22.0, -11.0), (22.0, -10.0), (22.0, -9.0), (22.0, -8.0), (22.0, -7.0), (22.0, -6.0), (23.0, -6.0), (23.0, -7.0), (23.0, -8.0), (23.0, -9.0), (23.0, -10.0), (23.0, -11.0), (23.0, -12.0), (23.0, -13.0), (23.0, -14.0), (23.0, -15.0), (24.0, -15.0), (24.0, -14.0), (24.0, -13.0), (24.0, -12.0), (24.0, -11.0), (24.0, -10.0), (24.0, -9.0), (24.0, -8.0), (24.0, -7.0), (24.0, -6.0), (25.0, -6.0), (25.0, -7.0), (25.0, -8.0), (25.0, -9.0), (25.0, -10.0), (25.0, -11.0), (25.0, -12.0), (25.0, -13.0), (25.0, -14.0), (25.0, -15.0)]

#initialize the dictionary for victim detection
victim_detected_by_robot = {robot_name:[]}
detected_victims_location = {}

#-------------------------robot initilization---------------------------
prox = ['RCPS4','LCPS4','RPS4','LPS4','RPS4']
pio2 = pioneer('PioneerP3DX4', 'rightMotor4', 'leftMotor4', prox, 34000)
pio2.Initialization(False)
a = 0



"""----------------------------------Create and set up the server---------------------------------"""
host = "127.0.0.5"
port = 43000
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((host, port))



"""---------------------------------------------------------------------------------------------------"""

def coverage_path_planning(sequence):
    for i in range(len(sequence)):
        try:
            status = func_timeout(30, pio2.move_p2p, args=(0,sequence[i]))
            print(status)
            if (status == 1):
                print("reached at ",sequence[i])

        except FunctionTimedOut:
            pass
    return True

def maintain_communication(server_socket):
    """
    Function to handle robot communication with victims.

    Args:
        server_socket (socket.socket): Pre-initialized server socket.
    """
    global victim_detected_by_robot, detected_victims_location
    victim_name = None  #initialize it to access from finally statement
    print("Robot communication thread started...")

    while True:
        # Listen for incoming connections
        server_socket.listen(5)
        print("Waiting for a victim to connect...")

        # Accept an incoming connection
        client_socket, addr = server_socket.accept()
        print(f"Connected to victim at {addr}")

        try:
            # Receive victim ID as the first message
            response = client_socket.recv(1024).decode()# Read victim ID (victim send in:'help_v1' format
            victim_name = response.split('_')[1]
            print(f"Victim ID received: {victim_name}")
            #print(type(victim_name))
            # Check if the victim ID is known and if the victim has already been recovered
            # if victim_id not in victim_positions:
            #     print(f"Unknown victim ID received: {victim_id}")
            #     client_socket.close()
            #     continue

            # Check if the victim has already been recovered by the robot
            if victim_name in victim_detected_by_robot[robot_name]:
                print(f"Victim {victim_name} has already been recovered by the robot. Closing communication.")
                client_socket.close()
                continue  # Move on to the next victim
            # check if the victim has already been rescued by other robot
            if is_victim_rescued('central_dictionary.txt',victim_name):
                continue


            # Get the position of the victim (for checking of less or greater than 2m distance)
            print(victim_name)
            victim_position = pio2.find_target_position(victim_name)
            print('victim position: ',victim_position)
            robot_position = pio2.robot_position()
            distance = math.sqrt((robot_position[0]-victim_position[0])**2+(robot_position[1]-victim_position[1])**2)
            print(f"Distance to {victim_name}: {distance:.2f} meters.")

            # If distance is greater than 2 meters, close the communication
            if distance > 2.0:
                print(f"Victim {victim_name} is more than 2 meters away. Closing communication.")
                message = ' Connection rejection due to over distance'
                client_socket.sendall(message.encode())
                client_socket.close()
                continue  # Move on to the next victim

            # Maintain communication as long as the distance is <= 2 meters
            while distance <= 2.0:
                print(f"Maintaining communication with victim {victim_name} (distance: {distance:.2f}m).")

                # Send "anyone" message to maintain communication
                message = "anyone"
                client_socket.sendall(message.encode())
                print(f"Sent message: {message}")

                # Receive the victim's response
                victim_loc = client_socket.recv(1024).decode()  # get victim location
                print(f"Received response of victim loc: {victim_loc}")

                # Update the dictionaries with the recovered victim
                if victim_name not in victim_detected_by_robot[robot_name]:
                    victim_detected_by_robot[robot_name].append(victim_name)
                    detected_victims_location[victim_name] = victim_loc
                    print(f"Updated dictionaries: {victim_detected_by_robot}, {detected_victims_location}")
                    update_victim_data('central_dictionary.txt',robot_name,victim_name,victim_loc)
                    message = 'rescued'
                    client_socket.sendall(message.encode())
                    break

        # except Exception as e:
        #     print(f"Error during communication: {e}")

        finally:
            # Close client socket and continue to listen for another connection
            print(f"Communication with victim {victim_name} ended.")
            #write_data_to_file('central_dictionary.txt',victim_detected_by_robot,detected_victims_location)
            #update_victim_data('central_dictionary.txt',robot_name,victim_name,victim_loc)
            client_socket.close()

        # Optional: Add a sleep or break condition if needed
        time.sleep(0.01)  # Add a small delay between communication rounds

    # Optionally, you can add server shutdown logic if needed outside the while loop
    server_socket.close()
    print("Robot communication thread terminated.")

# Shared event to signal the communication thread
stop_communication_event = threading.Event()

def main(sequence):
    path_planning_thread = threading.Thread(target=coverage_path_planning, args=(sequence,))
    communication_thread = threading.Thread(target=maintain_communication,args=(server_socket,))

    # Start the threads
    path_planning_thread.start()
    communication_thread.start()

    # Wait for both threads to complete
    path_planning_thread.join()
    communication_thread.join()

    print("All threads have completed.")
    return 0

if __name__ == "__main__":
    main(sequence)
pio2.set_velocity(0,0)
time.sleep(0.5)
sim.simxFinish(pio2.clientID)







